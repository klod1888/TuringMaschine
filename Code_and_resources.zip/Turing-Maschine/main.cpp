#include "turing-maschine.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
// Добавить защиту от ввода пробела в таблицув качестве символа
