#include "turing-maschine.h"
#include "ui_turing-maschine.h"
#include "QMessageBox"
#include "QTimer"
#include "QKeyEvent"

static int J7, NH=-116, BeginPos, SymPos=5, EndeSymPos=15, q=0, s=0, qp=1, SymH, fk, gk, gg, leerzeichen;
static QString Die_Symbol(""), qSym(""), buf, verschiben, symbol, strigoi, ErSym;
bool klk, LB;

void Neu_Stellen_Abc(Ui::MainWindow *gui)
{
    gui->tableWidget->setEnabled(1);
    for(int IchWill=0; IchWill<gui->tableWidget->columnCount(); IchWill++)
        gui->tableWidget->removeColumn(IchWill);
    for(int IchWill=0; IchWill<gui->tableWidget->rowCount(); IchWill++)
        gui->tableWidget->removeRow(IchWill);
    Die_Symbol.clear();



    gui->tableWidget->setRowCount(1);
    gui->tableWidget->setColumnCount(1);
    gui->tableWidget->setRowHeight(0, 35);
    gui->tableWidget->setColumnWidth(0,75);
    gui->tableWidget->setHorizontalHeaderItem(0, new QTableWidgetItem("a0"));
    gui->tableWidget->setVerticalHeaderItem(0, new QTableWidgetItem("q1"));
    gui->tableWidget->setItem(0,0, new QTableWidgetItem(""));
    gui->radioButton->setChecked(1);
    gui->radioButton_4->setChecked(1);
    gui->pushButton_8->setEnabled(0);

    s=0; q=0;
}

void Neu_Stellen_Band(Ui::MainWindow *gui)
{
    NH=-166;
    gui->tableWidget_2->setRowCount(1);
    gui->tableWidget_2->setColumnCount(333);
    gui->tableWidget_2->setRowHeight(0,50);
    gui->tableWidget_2->verticalHeader()->hide();
    gui->tableWidget_2->setFont(QFont("Tolstyak", 12));
    for(J7=0; J7<333; J7++)
    {
        gui->tableWidget_2->setItem(0,J7, new QTableWidgetItem(""));
        gui->tableWidget_2->setColumnWidth(J7,50);
        gui->tableWidget_2->setHorizontalHeaderItem(J7, new QTableWidgetItem(QString::number(NH)));
        NH++;
        gui->tableWidget_2->setItem(0,J7, new QTableWidgetItem(""));
        gui->tableWidget_2->item(0, J7)->setTextAlignment(Qt::AlignCenter);
    }
    gui->tableWidget_2->selectColumn(166);
    gui->tableWidget_2->scrollToItem(gui->tableWidget_2->item(0, 166+4), QAbstractItemView::ScrollHint());

    gui->radioButton->setChecked(1);
    gui->radioButton_4->setChecked(1);
    gui->pushButton_8->setEnabled(0);
}

void Halt_Maschine(Ui::MainWindow *gui)
{
    gui->tableWidget_2->selectColumn(166);
    gui->tableWidget_2->scrollToItem(gui->tableWidget_2->item(0, 166+4), QAbstractItemView::ScrollHint());
    gui->pushButton_2->setEnabled(0);
    gui->pushButton->setEnabled(1);
    gui->pushButton_8->setEnabled(0);
    gui->tableWidget->setEnabled(1);
    LB = false;
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //Illegale fans
    Neu_Stellen_Abc(ui);
    Neu_Stellen_Band(ui);
    // Fur Namen der Test
    /*for(int k=105; k<125; k++)
        ui->tableWidget_2->setItem(0,k, new QTableWidgetItem("+"));
    ui->tableWidget_2->setItem(0,103, new QTableWidgetItem("+"));*/
    // Ende der Test
    //Illegale, radikale, digitale fans
    timer = new QTimer(this);
    QObject::connect(timer, SIGNAL(timeout()), this, SLOT(on_timeout()));
}


MainWindow::~MainWindow()
{
    delete ui;
}

bool Revident_Lexik(QString str, Ui::MainWindow *gui)
{
    QRegExp reg("[0-9]+");
    leerzeichen = 0;
    QString streg = "";
    int qn;
    if(str[0]=='q' && str[1]!='0')
    {
        for(int lz=0; lz<str.size(); lz++)
            if(str[lz]==' ')
                leerzeichen++;
        if(leerzeichen<2)
            return 0;
        else if(leerzeichen>2)
            return 0;
        else
        {
            for(gk=0; gk<str.size(); gk++)
                if(str[gk] == ' ')
                    break;
            for(fk=1; fk<gk; fk++)
                streg += str[fk];
            if(reg.indexIn(streg)==-1)
                return 0;
            else qn = streg.toInt(&klk, 10);
            if(qn>gui->tableWidget->rowCount())
                return 0;
            for(gg=gk+1; gg<str.size(); gg++)
                if(str[gg]==' ')
                    break;
            verschiben = str[gg-1];
            if(verschiben!="Н" && verschiben!="Л" && verschiben!="П")/* || str[gk+2]!=' '*/
                return 0;
            if(str[gg+1]!='a' && str[gg+2]!='\0'/* || str[gg+2]!='0'/* && str[gg+3]!='\0'*/)
                return 0;
            else if(str[gg+1]=='a' && str[gg+2]!='0')
                return 0;
        }
    }
    else if(str[1]=='0' && str[2]=='\0')
        return 1;
    else return 0;
    return 1;
}

bool DetaillierteKasse(QString str, Ui::MainWindow *gui)
{
    bool Recht=true;
    QMessageBox msg;
    msg.setText("Все Gut!");
    QRegExp reg("[0-9]+");
    leerzeichen = 0;
    QString streg = "";
    int qn;
    if(str[0]=='q' && str[1]!='0')
    {
        for(int lz=0; lz<str.size(); lz++)
            if(str[lz]==' ')
                leerzeichen++;
        if(leerzeichen<2)
        {
            msg.setText("Недостаточно пробелов!");
            Recht=false;
        }
        else if(leerzeichen>2)
        {
            msg.setText("Пробелов слишком много!");
            Recht=false;
        }
        else
        {
            for(gk=0; gk<str.size(); gk++)
                if(str[gk] == ' ')
                    break;
            for(fk=1; fk<gk; fk++)
                streg += str[fk];
            if(reg.indexIn(streg)==-1)
            {
                msg.setText("Номер состояния не является числом!");
                Recht=false;
            }
            else qn = streg.toInt(&klk, 10);
            if(qn>gui->tableWidget->rowCount())
            {
                msg.setText("Состояние, на которое запланирован переход, не существует!");
                Recht=false;
            }
            for(gg=gk+1; gg<str.size(); gg++)
                if(str[gg]==' ')
                    break;
            verschiben = str[gg-1];
            if(verschiben!="Н" && verschiben!="Л" && verschiben!="П")
            {
                msg.setText("Команда движения каретки задана неверно!");
                Recht=false;
            }
            if(str[gg+1]!='a' && str[gg+2]!='\0')
            {
                msg.setText("Символ для замены установлен неверно или вообще не установлен!");
                Recht=false;
            }
            else if(str[gg+1]=='a' && str[gg+2]!='0')
            {
                msg.setText("Символ для замены установлен неверно или вообще не установлен!");
                Recht=false;
            }
        }
    }
    else if(str[1]=='0' && str[2]=='\0')
        Recht=true;
    else {msg.setText("Первый символ должен быть q!"); Recht=false;}
    msg.exec();
    return Recht;
}

void Parserung(QString str)
{
    QMessageBox msgBox;
    msgBox.setText("Parserung das ist Arsch");
    if(str[0]=='q')
    {
        for(gk=0; gk<str.size(); gk++)
            if(str[gk] == ' ')
                break;
        for(fk=1; fk<gk; fk++)
            buf+=str[fk];
        qp = buf.toInt(&klk, 10);
        buf.clear();
        for(gg=gk+1; gg<str.size(); gg++)
            if(str[gg]==' ')
                break;
        verschiben = str[gg-1];
        if(str[gg+1]=='a' && str[gg+2]=='0')
            symbol = "a0";
        else
            symbol = str[gg+1];
    }
    else msgBox.exec();
}

void Zug(Ui::MainWindow *gui)
{
    gui->tableWidget->selectionModel()->clearSelection();
    ErSym = gui->tableWidget_2->item(0, SymPos)->text();
    if(gui->tableWidget_2->item(0, SymPos)->text()=="")
    {
        strigoi = gui->tableWidget->item(qp-1, 0)->text();
        gui->tableWidget->item(qp-1, 0)->setSelected(1);
        gui->tableWidget->scrollToItem(gui->tableWidget->item(qp-1, 0), QAbstractItemView::ScrollHint());
    }
    else
    {
        for(int HH=0; HH<gui->tableWidget->columnCount(); HH++)
            if(gui->tableWidget->horizontalHeaderItem(HH)->text() == gui->tableWidget_2->item(0, SymPos)->text())
            {
                SymH = HH;
                break;
            }
        strigoi = gui->tableWidget->item(qp-1, SymH)->text();
        gui->tableWidget->item(qp-1, SymH)->setSelected(1);
        gui->tableWidget->scrollToItem(gui->tableWidget->item(qp-1, SymH), QAbstractItemView::ScrollHint());
    }
    Parserung(strigoi);
    if(qp!=0)
    {
        if(symbol == "a0")
            gui->tableWidget_2->setItem(0,SymPos, new QTableWidgetItem(""));
        else
            gui->tableWidget_2->setItem(0,SymPos, new QTableWidgetItem(symbol));
        gui->tableWidget_2->item(0, SymPos)->setTextAlignment(Qt::AlignCenter);
        if(verschiben=="Л")
            SymPos--;
        else if(verschiben=="П")
            SymPos++;
    }
}

void Grenze(int &BS, int &ES, Ui::MainWindow *gui)
{
    BS=0; ES=gui->tableWidget_2->columnCount();
    for(BS; BS<ES; BS++)
        if(gui->tableWidget_2->item(0,BS)->text()!="")
            break;
    for(ES-=1; ES>BS; ES--)
        if(gui->tableWidget_2->item(0,ES)->text()!="")
            break;
}

int ikl()
{
    int ikl;
    if(!SymPos)
        ikl=0;
    else if(verschiben=="П")
        ikl=1;
    else if(verschiben=="Л")
        ikl=-1;
    else ikl=0;
    return ikl;
}

bool Pruefung_die_Zeichen(Ui::MainWindow *gui)
{
    int count = 0;
    for(int kh=BeginPos; kh<EndeSymPos; kh++)
    {
        if(gui->tableWidget_2->item(0, kh)->text()!="")
        {
            QString strZ = gui->tableWidget_2->item(0,kh)->text();
            for(int ky=0; ky<Die_Symbol.count(); ky++)
            {
                if(strZ[0]==Die_Symbol[ky] || strZ=="")
                   count++;
            }
            if(count < 1)
                return 0;
            else count = 0;
        }
    }
    return 1;
}

bool BandIstZero(Ui::MainWindow *gui)
{
    int ksf=0;
    for(int ik=0; ik<gui->tableWidget_2->columnCount(); ik++)
        if(gui->tableWidget_2->item(0, ik)->text()=="")
            ksf++;
    if(ksf==gui->tableWidget_2->columnCount())
        return false;
    else return true;
}

void Umzug(Ui::MainWindow *gui)
{
    if(SymPos>=0 && SymPos<=gui->tableWidget_2->columnCount() && qp!=0 && LB)
    {

        gui->tableWidget_2->scrollToItem(gui->tableWidget_2->item(0, SymPos), QAbstractItemView::ScrollHint());
        gui->tableWidget_2->item(0, SymPos-ikl())->setSelected(0);
        gui->tableWidget_2->selectionModel()->clearSelection();
        gui->tableWidget_2->item(0, SymPos)->setSelected(1);
        //gui->tableWidget->selectionModel()->clearSelection();
        Zug(gui);
    }
    else
    {
        QMessageBox msg_eins;
        msg_eins.setText("Работа машины завершена. Все команды выполнены!");
        msg_eins.exec();
        gui->pushButton_2->setEnabled(0);
        gui->pushButton->setEnabled(1);
        gui->pushButton_8->setEnabled(0);
        gui->tableWidget->setEnabled(1);
        qp = 1;
        LB = false;
    }
}

void MainWindow::on_timeout()
{
    if(!LB)
        timer->stop();
    else Umzug(ui);
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if(event->key()==Qt::Key_F3)
    {
        QMessageBox lbm;
        static QString restr;
        int x,y;
        x = ui->tableWidget->currentColumn();
        y = ui->tableWidget->currentRow();
        if(ui->tableWidget->currentItem())
        {
            restr = ui->tableWidget->currentItem()->text();
            if(DetaillierteKasse(restr, ui))
                ui->tableWidget->currentItem()->setBackgroundColor(QColor(0,255,0));
            else ui->tableWidget->currentItem()->setBackgroundColor(QColor(255,0,0));
        }
        else
        {
            lbm.setText("Ячейка не инициирована");
            lbm.exec();
        }
    }
}

void MainWindow::on_pushButton_clicked()
{
    bool pro=true;
    if(Pruefung_die_Zeichen(ui) && BandIstZero(ui))
    {
        ui->pushButton->setEnabled(0);
        ui->pushButton_8->setEnabled(1);
        ui->tableWidget->setEnabled(0);
        ui->tableWidget_2->selectionModel()->clearSelection();
        ui->tableWidget->selectionModel()->clearSelection();
        for(int uy=0; uy<ui->tableWidget->rowCount(); uy++)
            for(int uk=0; uk<ui->tableWidget->columnCount(); uk++)
            {
                strigoi = ui->tableWidget->item(uy, uk)->text();
                if(!Revident_Lexik(strigoi, ui))
                {
                    ui->tableWidget->item(uy, uk)->setBackgroundColor(QColor(255,0,0));
                    pro=false;
                }
                else ui->tableWidget->item(uy, uk)->setBackgroundColor(QColor(0,255,0));
            }
        if(!pro)
        {
            QMessageBox pars2;
            pars2.setText("В командах для машины допущены ошибки!!!");
            pars2.exec();
            ui->pushButton->setEnabled(1);
            ui->pushButton_2->setEnabled(0);
            ui->pushButton_8->setEnabled(0);
            ui->tableWidget->setEnabled(1);
            pro = true;
            return;
        }
        Grenze(BeginPos, EndeSymPos, ui);
        if(ui->radioButton->isChecked())
            SymPos = BeginPos;
        if(ui->radioButton_2->isChecked())
            SymPos = EndeSymPos;
        if(ui->radioButton_3->isChecked())
            SymPos = ui->tableWidget_2->currentItem()->column();
        // Modus
        LB=true;
        if(ui->radioButton_4->isChecked())
            ui->pushButton_2->setEnabled(1);
        else if(ui->radioButton_5->isChecked())
        {
            timer->start(ui->spinBox->value()*1000);
        }
        else
        {
            while(LB)
                Umzug(ui);
        }
    }
    else if(!Pruefung_die_Zeichen(ui))
    {
        QMessageBox error14;
        error14.setText("На ленте присутствуют символы, отсутствующие в алфавите!");
        error14.exec();
    }
    else
    {
        QMessageBox error88;
        error88.setText("Лента совсем пуста!");
        error88.exec();
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    //  Die Schaltfläche für den folgenden Schritt
    Umzug(ui);
}

void InitializationZellen(int q, int s, Ui::MainWindow *gui)
{
    for(int qq=0; qq<=q; qq++)
        for(int ss=0; ss<=s; ss++)
        {
            if(!gui->tableWidget->item(qq,ss))
                gui->tableWidget->setItem(qq, ss, new QTableWidgetItem(""));
        }
}

bool Pruefung_der_Symbole(QString PrSym)
{
    for(int si=0; si<Die_Symbol.length(); si++)
        if(Die_Symbol[si]==PrSym[0])
            return 0;
    return 1;
}



void MainWindow::on_pushButton_3_clicked()
{
    if(ui->lineEdit->text()!="" && Pruefung_der_Symbole(ui->lineEdit->text()))
    {
        q++;
        ui->tableWidget->setColumnCount(q+1);
        ui->tableWidget->setColumnWidth(q,75);
        ui->tableWidget->setHorizontalHeaderItem(q, new QTableWidgetItem(ui->lineEdit->text()));
        InitializationZellen(q, s, ui);
        Die_Symbol+=ui->lineEdit->text();
    }
    else if(!Pruefung_der_Symbole(ui->lineEdit->text()))
    {
        QMessageBox syms2;
        syms2.setText("Этот символ уже есть!!!");
        syms2.exec();
    }
    else
    {
        QMessageBox syms;
        syms.setText("Вы не ввели добавляемый символ!!!");
        syms.exec();
    }
}

void MainWindow::on_pushButton_4_clicked()
{
    s++;
    ui->tableWidget->setRowCount(s+1);
    ui->tableWidget->setRowHeight(s, 35);
    qSym = "q";
    qSym += QString::number(s+1);
    ui->tableWidget->setVerticalHeaderItem(s, new QTableWidgetItem(qSym));
    InitializationZellen(q, s, ui);
}

void MainWindow::on_pushButton_5_clicked()
{
    int cc = ui->tableWidget->currentColumn();
    if(cc)
    {
        QString str = ui->tableWidget->horizontalHeaderItem(cc)->text();
        for(int kl=0; kl<Die_Symbol.count(); kl++)
            if(Die_Symbol[kl]==str[0])
                Die_Symbol.remove(kl,1);
        ui->tableWidget->removeColumn(ui->tableWidget->currentColumn());
        q--;
    }
}

void MainWindow::on_pushButton_6_clicked()
{
    int cc = ui->tableWidget->currentRow();
    if(cc)
    {
        ui->tableWidget->removeRow(ui->tableWidget->rowCount()-1);
        s--;
    }
}

void MainWindow::on_pushButton_7_clicked()
{
    Neu_Stellen_Band(ui);
}

void MainWindow::on_pushButton_8_clicked()
{
    Halt_Maschine(ui);
}

void MainWindow::on_pushButton_9_clicked()
{
    Neu_Stellen_Abc(ui);
}
